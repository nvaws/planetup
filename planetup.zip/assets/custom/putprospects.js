$(document).ready(function() {
        $("#myForm").on("submit", function(e) {
          e.preventDefault();
          let name = $("#name-header15-1").val();
          let email = $("#email-header15-1").val();
          let phone = $("#phone-header15-1").val();
          let message = $("#message-header15-1").val();
          fetch(
            "<Invoke URL>",
            {
              method: "post",
              mode: "cors",
              headers: {
                Accept: "application/json, text/plain, */*",
                "Content-Type": "application/json"
              },
              body: JSON.stringify({
                name: name,
                email: email,
                phone: phone,
                message: message
              })
            }
          )
            .then(res => res.json())
            .then(res => console.log(res))
            .catch(err => console.log(err));
        });
      });